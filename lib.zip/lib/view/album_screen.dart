import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/album_controller.dart';

class AlbumScreen extends StatelessWidget {
  final  Controller _controller = Get.put(Controller());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fecting Api Data'),
      ),
      body: Center(
        child: Container(
          width: 300,
          child: ListView(
            children: [
              SizedBox(height: 50,),
              Obx(() => Text(_controller.data.value)),
            ],
          ),
        ),
      )
    );
  }
}
