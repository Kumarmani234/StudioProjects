
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class Controller extends GetxController {
  var data = ''.obs;
  @override
  void onInit() {
    fetchData();
    super.onInit();
  }

  void fetchData() async {
    var response = await http.get(Uri.parse('http://jsonplaceholder.typicode.com/albums'));
    data.value = response.body;
  }
}
